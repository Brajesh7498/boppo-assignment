<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class login extends CI_Controller {

	
	public function index()
	{
		// echo password_hash('1234', PASSWORD_DEFAULT);
		$this->load->library('form_validation');
		$this->load->view('employee/login');
	}
	public function authenticate(){
		$this->load->library('form_validation');
		$this->load->model('Admin_model');

		$this->form_validation->set_rules('name','Name', 'trim|required');
		$this->form_validation->set_rules('password','Password', 'trim|required');
		if ($this->form_validation->run() == true) {
			// sucess
			$name = $this->input->post('name');
			$admin = $this->Admin_model->getByUsername($name);
			if (!empty($admin)) {
				$password = $this->input->post('password');
				if (password_verify($password, $admin['password']) == true) {
					$adminArray['admin_id'] = $admin['id'];
					$adminArray['name'] = $admin['name'];
					$this->session->set_userdata('admin', $adminArray);
					redirect(base_url().'index.php/EmployeeModel/index');
				}else{
					$this->session->set_flashdata('msg', 'Either userrname or password Incorrect');
					redirect(base_url().'index.php/login/index');
				}
			}
			else
			{ 
				$this->session->set_flashdata('msg', 'Either userrname or password Incorrect');
				redirect(base_url().'index.php/login/index');
			}
		} else {
			$this->load->view('login');
			// code...
		}
		

	}
	function logout(){
		$this->session->sess_destroy();
		redirect(base_url().'index.php/login/index');
	}
}