<?php 
	class EmployeeModel extends CI_Controller{

		public function __construct(){
		parent::__construct();
		$admin = $this->session->userdata('admin');
		if (empty($admin)){
			$this->session->set_flashdata('msg','please login');
			redirect(base_url().'index.php/login/index');
			}
		}

		function index() {
			$this->load->model('Model_employee');
			
			$rows = $this->Model_employee->all();
			$data['rows'] = $rows;
			//print_r($data);
			$this->load->view('employee/list.php', $data);
		}

		function showEmployeeForm() {
			$html=$this->load->view('employee/create.php','',true);
			$response['html'] = $html;
			echo json_encode($response);
			
		}

		function saveEmployee() {
			$this->load->model('Model_employee');			
			$this->load->library('encryption');

			//file upload setting
			$config['upload_path']      = './public/uploads/';
            $config['allowed_types']    = 'gif|jpg|png';
            $config['encrypt_name'] =true;

            $this->load->library('upload', $config);
            

			$this->load->library('form_validation');
			$this->form_validation->set_rules('name','Name','required');
			$this->form_validation->set_rules('dob','DOB','required');
			$this->form_validation->set_rules('age','age','required');
			$this->form_validation->set_rules('mobile','Mobile','required');
			$this->form_validation->set_rules('skill','Skill','required');
			$this->form_validation->set_rules('gender','Gender','required');
			$this->form_validation->set_rules('designation','Designation','required');
			$this->form_validation->set_rules('address','Address','required');
			$this->form_validation->set_rules('username','Username','required');
			$this->form_validation->set_rules('password1','Password','required');
			$this->form_validation->set_rules('password2','Confirm password','required');

			if($this->form_validation->run() == true) { //save

				if (isset($_FILES['image']['name'])) {
					if($this->upload->do_upload('image')){
					// Image successfully uploaded here...
					$data= $this->upload->data();

					$formArray = array();

					$formArray['image'] = $data['file_name'];

					$formArray['name'] = $this->input->post('name');
					$formArray['dob'] = $this->input->post('dob');
					$formArray['age'] = $this->input->post('age');
					$formArray['mobile'] = $this->input->post('mobile');
					$formArray['skill'] = $this->input->post('skill');
					$formArray['gender'] = $this->input->post('gender');
					$formArray['designation'] = $this->input->post('designation');
					$formArray['address'] = $this->input->post('address');
					$formArray['username'] = $this->input->post('username');
					$formArray['password'] = $this->encryption->encrypt($this->input->post('password1'));
					$formArray['confirm_password'] = $this->encryption->encrypt($this->input->post('password2'));

					$id = $this->Model_employee->create($formArray);

					$row = $this->Model_employee->getrow($id);
					$vData['row'] = $row;
					$rowHtml = $this->load->view('employee/employee_row', $vData, true);
					$response['row']=$rowHtml;

					$response['status']=1;
					$response['message']="<div class='alert alert-success'>Employee Has been added successfully!</div>";
					} else {
						//Some errors in file uploading
						$response['status']=0;
						$response['image']=strip_tags(form_error('image'));
					}
				}else{
					$formArray = array();

					$formArray['name'] = $this->input->post('name');
					$formArray['dob'] = $this->input->post('dob');
					$formArray['age'] = $this->input->post('age');
					$formArray['mobile'] = $this->input->post('mobile');
					$formArray['skill'] = $this->input->post('skill');
					$formArray['gender'] = $this->input->post('gender');
					$formArray['designation'] = $this->input->post('designation');
					$formArray['address'] = $this->input->post('address');
					$formArray['username'] = $this->input->post('username');
					$formArray['password'] = $this->encryption->encrypt($this->input->post('password1'));
					$formArray['confirm_password'] = $this->encryption->encrypt($this->input->post('password2'));	
					$id = $this->Model_employee->create($formArray);

					$row = $this->Model_employee->getrow($id);
					$vData['row'] = $row;
					$rowHtml = $this->load->view('employee/employee_row', $vData, true);
					$response['row']=$rowHtml;

					$response['status']=1;
					$response['message']="<div class='alert alert-success'>Employee Has been added successfully!</div>";
				}
			}else{ //error msgs
				$response['status']=0;
				$response['name']=strip_tags(form_error('name'));				
				$response['dob']=strip_tags(form_error('dob'));				
				$response['age']=strip_tags(form_error('age'));				
				$response['mobile']=strip_tags(form_error('mobile'));				
				$response['skill']=strip_tags(form_error('skill'));				
				$response['gender']=strip_tags(form_error('gender'));				
				$response['designation']=strip_tags(form_error('designation'));				
				$response['address']=strip_tags(form_error('address'));				
				$response['username']=strip_tags(form_error('username'));				
				$response['password1']=strip_tags(form_error('password1'));				
				$response['password2']=strip_tags(form_error('password2'));				
			}

			echo json_encode($response);
		}

		function getEmployeeModel($id){
			$this->load->model('Model_employee');
			$row = $this->Model_employee->getRow($id);

			$data['row'] = $row;
			$html=$this->load->view('employee/edit.php',$data,true);
			$response['html'] = $html;
			echo json_encode($response);
		}

//Update
		function updateEmployee(){
			$this->load->model('Model_employee');	
			$this->load->library('encryption');

			$id = $this->input->post('id');	
			$row = $this->Model_employee->getRow($id);				

			if(empty($row)){
				$response['msg']="Either record Deleted or not found";
				$response['status']=100;
				json_decode($response);
				exit;
			}

			//file upload setting
			$config['upload_path']      = './public/uploads/';
            $config['allowed_types']    = 'gif|jpg|png';
            $config['encrypt_name'] =true;

            $this->load->library('upload', $config);
            

			$this->load->library('form_validation');
			$this->form_validation->set_rules('name','Name','required');
			$this->form_validation->set_rules('dob','DOB','required');
			$this->form_validation->set_rules('age','age','required');
			$this->form_validation->set_rules('mobile','Mobile','required');
			$this->form_validation->set_rules('skill','Skill','required');
			$this->form_validation->set_rules('gender','Gender','required');
			$this->form_validation->set_rules('designation','Designation','required');
			$this->form_validation->set_rules('address','Address','required');
			$this->form_validation->set_rules('username','Username','required');
			$this->form_validation->set_rules('password1','Password','required');
			$this->form_validation->set_rules('password2','Confirm password','required');

			if($this->form_validation->run() == true) { //save

				if (isset($_FILES['image']['name'])) {
					if($this->upload->do_upload('image')){
					// Image successfully uploaded here...
					$data= $this->upload->data();

					$formArray = array();

					$formArray['image'] = $data['file_name'];

					$formArray['name'] = $this->input->post('name');
					$formArray['dob'] = $this->input->post('dob');
					$formArray['age'] = $this->input->post('age');
					$formArray['mobile'] = $this->input->post('mobile');
					$formArray['skill'] = $this->input->post('skill');
					$formArray['gender'] = $this->input->post('gender');
					$formArray['designation'] = $this->input->post('designation');
					$formArray['address'] = $this->input->post('address');
					$formArray['username'] = $this->input->post('username');
					$formArray['password'] = $this->encryption->encrypt($this->input->post('password1'));
					$formArray['confirm_password'] = $this->encryption->encrypt($this->input->post('password2'));

					$id = $this->Model_employee->update($id,$formArray);

					$row = $this->Model_employee->getrow($id);
					$response['row']=$row;

					$response['status']=1;
					$response['message']="<div class='alert alert-success'>Employee Has been Updated successfully!</div>";
					} else {
						//Some errors in file uploading
						$response['status']=0;
						$response['image']=strip_tags(form_error('image'));
					}
				}else{
					$formArray = array();

					$formArray['name'] = $this->input->post('name');
					$formArray['dob'] = $this->input->post('dob');
					$formArray['age'] = $this->input->post('age');
					$formArray['mobile'] = $this->input->post('mobile');
					$formArray['skill'] = $this->input->post('skill');
					$formArray['gender'] = $this->input->post('gender');
					$formArray['designation'] = $this->input->post('designation');
					$formArray['address'] = $this->input->post('address');
					$formArray['username'] = $this->input->post('username');
					$formArray['password'] = $this->encryption->encrypt($this->input->post('password1'));
					$formArray['confirm_password'] = $this->encryption->encrypt($this->input->post('password2'));	
					$id = $this->Model_employee->update($id,$formArray);

					$row = $this->Model_employee->getrow($id);

					$response['row']=$row;

					$response['status']=1;
					$response['message']="<div class='alert alert-success'>Employee Has been Updated successfully!</div>";
				}
			}else{ //error msgs
				$response['status']=0;
				$response['name']=strip_tags(form_error('name'));				
				$response['dob']=strip_tags(form_error('dob'));				
				$response['age']=strip_tags(form_error('age'));				
				$response['mobile']=strip_tags(form_error('mobile'));				
				$response['skill']=strip_tags(form_error('skill'));				
				$response['gender']=strip_tags(form_error('gender'));				
				$response['designation']=strip_tags(form_error('designation'));				
				$response['address']=strip_tags(form_error('address'));				
				$response['username']=strip_tags(form_error('username'));				
				$response['password1']=strip_tags(form_error('password1'));				
				$response['password2']=strip_tags(form_error('password2'));				
			}

			echo json_encode($response);
		}

		function deleteModel($id){
			$this->load->model('Model_employee');
			$row = $this->Model_employee->getrow($id);

			if(empty($row)){
				$response['msg']="Either record already Deleted or not found";
				$response['status']=0;
			echo json_encode($response);
				exit;
			}else{
				$this->Model_employee->delete($id);
				$response['msg']="<div class='alert alert-success'>Record das been Deleted successfully</div>";
				$response['status']=1;
			echo json_encode($response);
			}
		}
	}
?>