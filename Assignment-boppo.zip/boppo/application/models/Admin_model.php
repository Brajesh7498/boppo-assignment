<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model{

	
	public function getByUsername($name)
	{
		$this->db->where('name', $name);
		$admin = $this->db->get('adminreg')->row_array();
		return $admin;
	}
}