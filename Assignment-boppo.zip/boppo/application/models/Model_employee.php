<?php 
	class Model_employee extends CI_model{

		public function create($formArray) {
			$this->db->insert('employee', $formArray);
			return $id = $this->db->insert_id();
		}

		public function all() {
			$result=$this->db->order_by('id','DESC')->get('employee')->result_array();
			return $result;
		}

		function getRow($id){
			$this->db->where('id',$id);
			$row = $this->db->get('employee')->row_array();
			return $row;
		}

		function update($id,$formArray){
			$this->db->where('id', $id);
			$this->db->update('employee',$formArray);
			return $id;
		}

		function delete($id){
			$this->db->where('id', $id);
			$this->db->delete('employee');
		}
	}
?>