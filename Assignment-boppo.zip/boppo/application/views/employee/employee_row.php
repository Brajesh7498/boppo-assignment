
<tr>
	<td><?php echo $row['id']; ?></td>				
	<td><?php echo $row['name']; ?></td>
	<td><?php echo $row['username']; ?></td>
	<td><?php echo $row['dob']; ?></td>
	<td><?php echo $row['age']; ?></td>
	<td><?php echo $row['mobile']; ?></td>
	<td><?php echo $row['skill']; ?></td>
	<td><?php echo $row['gender']; ?></td>
	<td><?php echo $row['designation']; ?></td>
	<td><?php echo $row['address']; ?></td>
	<td><?php echo $row['image']; ?></td>
	<td><a href="javascript:void(0);" onclick="showEditForm(<?php echo $row['id']; ?>)" class="btn btn-primary"> Update</a></td>
	<td><a href="javascript:void(0);" onclick="confirmDeleteModel(<?php echo $row['id']; ?>)" class="btn btn-danger">Delete</a></td>
</tr>
		