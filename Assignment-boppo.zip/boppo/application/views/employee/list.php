<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Employees</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
	<script src="<?php echo base_url(); ?>assets/js/jquery-3.4.1.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/style.css">
	<style type="text/css">
		table.table-sortable th.currently-sorted[data-sort-dir="asc"]::after {
	    content: "\25b2";
		}

		table.table-sortable th.currently-sorted[data-sort-dir="desc"]::after {
		    content: "\25bc";
		}
	</style>
</head>
<body>
	<div class="header">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<h3 class="heading">Employees</h3>
				</div>
				<div class="col-md-6 pt-2">
					<a style="float: right;" class="btn btn-danger" href="<?php echo base_url().'index.php/login/logout'; ?>">Logout</a>
				</div>
			</div>			
		</div>		
	</div>
	<div class="container">
		<div class="row pt-4">
			<div class="col-md-6">
				<h4>Employee List</h4>

			</div>
			<div class="col-md-6">
				<a href="javascript:void(0);" onclick="showModal()" class="btn btn-primary add">Add Employee</a>
			</div>
			<div class="col-md-12 pt-4">
				<table class="table table-strip table-sortable" id="EmployeeList">
					<thead>
						<tr>
							<th >#</th>
							<th data-sort-type="text">Name</th>
							<th data-sort-type="text">User Name</th>
							<th data-sort-type="numeric">DOB</th>
							<th data-sort-type="numeric">Age</th>
							<th data-sort-type="numeric">Mobile</th>
							<th data-sort-type="text">Skill</th>
							<th data-sort-type="text">Gender</th>
							<th data-sort-type="text">Designation</th>
							<th data-sort-type="text">Address</th>
							<th>Photo</th>					
							<th>Update</th>					
							<th>Delete</th>					
						</tr>
					</thead>					
                    <tbody>
                    <?php if (!empty($rows)) { 
						$i=1;
                      foreach($rows as $empRow){
                      ?>
						<tr id="row-<?php echo $empRow['id']; ?>">
							<td class="modelId"><?php echo $i++; ?></td>				
							<td class="modelName"><?php echo $empRow['name']; ?></td>
	                		<td class="modelUsername"><?php echo $empRow['username']; ?></td>
	                		<td class="modelDob"><?php echo $empRow['dob']; ?></td>
	                		<td class="modelAge"><?php echo $empRow['age']; ?></td>
	                		<td class="modelMobile"><?php echo $empRow['mobile']; ?></td>
	                		<td class="modelSkill"><?php echo $empRow['skill']; ?></td>
	                		<td class="modelGender"><?php echo $empRow['gender']; ?></td>
	                		<td class="modelDesignation"><?php echo $empRow['designation']; ?></td>
	                		<td class="modelAddress"><?php echo $empRow['address']; ?></td>
	                		<td class="modelImage"><?php echo $empRow['image']; ?></td>
	                		<td><a href="javascript:void(0);" onclick="showEditForm(<?php echo $empRow['id']; ?>)" class="btn btn-primary"> Update</a></td>
	                		<td><a href="javascript:void(0);" onclick="confirmDeleteModel(<?php echo $empRow['id']; ?>)" class="btn btn-danger">Delete</a></td>
						</tr>
						<?php } }else{?>
						<tr>
	                      <td colspan="12">Record Not Found</td>
	                    </tr>
	                	<?php } ?>
	                </tbody>
				</table>	
			</div>			
		</div>			
	</div>


	<!-- Modal -->
	<div class="modal fade" id="addEmployee" tabindex="-1" role="dialog" aria-hidden="true">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel"></h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div id="response">
	      	
	      </div>	      
	    </div>
	  </div>
	</div>

	<!-- Modal -->
	<div class="modal fade" id="ajax_Response" tabindex="-1" role="dialog" aria-hidden="true">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Alert</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      	<div class="modal-body">
	      	</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			</div>	      	
	    </div>
	  </div>
	</div>

	<!-- Modal Delete-->
	<div class="modal fade" id="deleteModel" tabindex="-1" role="dialog" aria-hidden="true">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Confirmation</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      	<div class="modal-body">
	      	</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				<button onclick="deleteNow()" class="btn btn-danger">Yes</button>
			</div>	      	
	    </div>
	  </div>
	</div>

	<script type="text/javascript">
		function showModal() {
			$("#addEmployee").modal("show");
			$("#addEmployee .modal-title").html("Add Employee");
			$.ajax({
				url: '<?php echo base_url().'index.php/EmployeeModel/showEmployeeForm'; ?>',
				type: 'POST',
				data: {},
				dataType: 'json',
				success: function(response){
					$("#response").html(response["html"]);
				}
			});
		}

		$("body").on("submit","#EmployeeModel", function(e){
			e.preventDefault();
			
			$.ajax({
				url: '<?php echo base_url().'index.php/EmployeeModel/saveEmployee'; ?>',
				type: 'POST',
				data: $(this).serializeArray(),				
				dataType: 'json',
				success: function(response){
					if (response['status'] == 0) {
						if(response['name'] != '') {
							$(".nameError").html(response["name"]).addClass('invalid-feedback d-block');
							$("#name").addClass('is-invalid');
						} else {
							$(".nameError").html("").removeClass('invalid-feedback d-block');
							$("#name").removeClass('is-invalid');
						}

						if(response['address'] != '') {
							$(".addressError").html(response["address"]).addClass('invalid-feedback d-block');
							$("#address").addClass('is-invalid');
						} else {
							$(".addressError").html("").removeClass('invalid-feedback d-block');
							$("#address").removeClass('is-invalid');
						}

						if(response['age'] != '') {
							$(".ageError").html(response["age"]).addClass('invalid-feedback d-block');
							$("#age").addClass('is-invalid');
						} else {
							$(".ageError").html("").removeClass('invalid-feedback d-block');
							$("#age").removeClass('is-invalid');
						}

						if(response['designation'] != '') {
							$(".designationError").html(response["designation"]).addClass('invalid-feedback d-block');
							$("#designation").addClass('is-invalid');
						} else {
							$(".designationError").html("").removeClass('invalid-feedback d-block');
							$("#designation").removeClass('is-invalid');
						}

						if(response['dob'] != '') {
							$(".dobError").html(response["dob"]).addClass('invalid-feedback d-block');
							$("#dob").addClass('is-invalid');
						} else {
							$(".dobError").html("").removeClass('invalid-feedback d-block');
							$("#dob").removeClass('is-invalid');
						}

						if(response['gender'] != '') {
							$(".genderError").html(response["gender"]).addClass('invalid-feedback d-block');
							$("#gender").addClass('is-invalid');
						} else {
							$(".genderError").html("").removeClass('invalid-feedback d-block');
							$("#gender").removeClass('is-invalid');
						}

						if(response['mobile'] != '') {
							$(".mobileError").html(response["mobile"]).addClass('invalid-feedback d-block');
							$("#mobile").addClass('is-invalid');
						} else {
							$(".mobileError").html("").removeClass('invalid-feedback d-block');
							$("#mobile").removeClass('is-invalid');
						}

						if(response['skill'] != '') {
							$(".skillError").html(response["skill"]).addClass('invalid-feedback d-block');
							$("#skill").addClass('is-invalid');
						} else {
							$(".skillError").html("").removeClass('invalid-feedback d-block');
							$("#skill").removeClass('is-invalid');
						}

						if(response['username'] != '') {
							$(".usernameError").html(response["username"]).addClass('invalid-feedback d-block');
							$("#username").addClass('is-invalid');
						} else {
							$(".usernameError").html("").removeClass('invalid-feedback d-block');
							$("#username").removeClass('is-invalid');
						}

						if(response['password1'] != '') {
							$(".password1Error").html(response["password1"]).addClass('invalid-feedback d-block');
							$("#password1").addClass('is-invalid');
						} else {
							$(".password1Error").html("").removeClass('invalid-feedback d-block');
							$("#password1").removeClass('is-invalid');
						}

						if(response['password2'] != '') {
							$(".password2Error").html(response["password2"]).addClass('invalid-feedback d-block');
							$("#password2").addClass('is-invalid');
						} else {
							$(".password2Error").html("").removeClass('invalid-feedback d-block');
							$("#password2").removeClass('is-invalid');
						}
					} else {
						$("#addEmployee").modal("hide");
						$("#ajax_Response .modal-body").html(response['message'])
						$("#ajax_Response").modal("show");

						$(".nameError").html("").removeClass('invalid-feedback d-block');
						$("#name").removeClass('is-invalid');
						$(".addressError").html("").removeClass('invalid-feedback d-block');
						$("#address").removeClass('is-invalid');
						$(".ageError").html("").removeClass('invalid-feedback d-block');
						$("#age").removeClass('is-invalid');
						$(".designationError").html("").removeClass('invalid-feedback d-block');
						$("#designation").removeClass('is-invalid');
						$(".dobError").html("").removeClass('invalid-feedback d-block');
						$("#dob").removeClass('is-invalid');
						$(".genderError").html("").removeClass('invalid-feedback d-block');
						$("#gender").removeClass('is-invalid');
						$(".mobileError").html("").removeClass('invalid-feedback d-block');
						$("#mobile").removeClass('is-invalid');
						$(".skillError").html("").removeClass('invalid-feedback d-block');
						$("#skill").removeClass('is-invalid');
						$(".usernameError").html("").removeClass('invalid-feedback d-block');
						$("#username").removeClass('is-invalid');
						$(".password1Error").html("").removeClass('invalid-feedback d-block');
						$("#password1").removeClass('is-invalid');
						$(".password2Error").html("").removeClass('invalid-feedback d-block');
						$("#password2").removeClass('is-invalid');

						$("#EmployeeList").append(response["row"]);
					}
				}
			});
		});

	function showEditForm(id) { 
		$("#addEmployee .modal-title").html("Edit Employee");
		$.ajax({
				url: '<?php echo base_url().'index.php/EmployeeModel/getEmployeeModel/' ?>'+id,
				type: 'POST',
				dataType: 'json',
				success: function(response){
					$("#addEmployee #response").html(response["html"]);
					$("#addEmployee").modal("show");
				}
			});
	}

//Edit
	$("body").on("submit","#editEmployeeModel", function(e){
			e.preventDefault();
			
			$.ajax({
				url: '<?php echo base_url().'index.php/EmployeeModel/updateEmployee'; ?>',
				type: 'POST',
				data: $(this).serializeArray(),				
				dataType: 'json',
				success: function(response){
					if (response['status'] == 0) {
						if(response['name'] != '') {
							$(".nameError").html(response["name"]).addClass('invalid-feedback d-block');
							$("#name").addClass('is-invalid');
						} else {
							$(".nameError").html("").removeClass('invalid-feedback d-block');
							$("#name").removeClass('is-invalid');
						}

						if(response['address'] != '') {
							$(".addressError").html(response["address"]).addClass('invalid-feedback d-block');
							$("#address").addClass('is-invalid');
						} else {
							$(".addressError").html("").removeClass('invalid-feedback d-block');
							$("#address").removeClass('is-invalid');
						}

						if(response['age'] != '') {
							$(".ageError").html(response["age"]).addClass('invalid-feedback d-block');
							$("#age").addClass('is-invalid');
						} else {
							$(".ageError").html("").removeClass('invalid-feedback d-block');
							$("#age").removeClass('is-invalid');
						}

						if(response['designation'] != '') {
							$(".designationError").html(response["designation"]).addClass('invalid-feedback d-block');
							$("#designation").addClass('is-invalid');
						} else {
							$(".designationError").html("").removeClass('invalid-feedback d-block');
							$("#designation").removeClass('is-invalid');
						}

						if(response['dob'] != '') {
							$(".dobError").html(response["dob"]).addClass('invalid-feedback d-block');
							$("#dob").addClass('is-invalid');
						} else {
							$(".dobError").html("").removeClass('invalid-feedback d-block');
							$("#dob").removeClass('is-invalid');
						}

						if(response['gender'] != '') {
							$(".genderError").html(response["gender"]).addClass('invalid-feedback d-block');
							$("#gender").addClass('is-invalid');
						} else {
							$(".genderError").html("").removeClass('invalid-feedback d-block');
							$("#gender").removeClass('is-invalid');
						}

						if(response['mobile'] != '') {
							$(".mobileError").html(response["mobile"]).addClass('invalid-feedback d-block');
							$("#mobile").addClass('is-invalid');
						} else {
							$(".mobileError").html("").removeClass('invalid-feedback d-block');
							$("#mobile").removeClass('is-invalid');
						}

						if(response['skill'] != '') {
							$(".skillError").html(response["skill"]).addClass('invalid-feedback d-block');
							$("#skill").addClass('is-invalid');
						} else {
							$(".skillError").html("").removeClass('invalid-feedback d-block');
							$("#skill").removeClass('is-invalid');
						}

						if(response['username'] != '') {
							$(".usernameError").html(response["username"]).addClass('invalid-feedback d-block');
							$("#username").addClass('is-invalid');
						} else {
							$(".usernameError").html("").removeClass('invalid-feedback d-block');
							$("#username").removeClass('is-invalid');
						}

						if(response['password1'] != '') {
							$(".password1Error").html(response["password1"]).addClass('invalid-feedback d-block');
							$("#password1").addClass('is-invalid');
						} else {
							$(".password1Error").html("").removeClass('invalid-feedback d-block');
							$("#password1").removeClass('is-invalid');
						}

						if(response['password2'] != '') {
							$(".password2Error").html(response["password2"]).addClass('invalid-feedback d-block');
							$("#password2").addClass('is-invalid');
						} else {
							$(".password2Error").html("").removeClass('invalid-feedback d-block');
							$("#password2").removeClass('is-invalid');
						}
					} else {
						$("#addEmployee").modal("hide");
						$("#ajax_Response .modal-body").html(response['message'])
						$("#ajax_Response").modal("show");

						$(".nameError").html("").removeClass('invalid-feedback d-block');
						$("#name").removeClass('is-invalid');
						$(".addressError").html("").removeClass('invalid-feedback d-block');
						$("#address").removeClass('is-invalid');
						$(".ageError").html("").removeClass('invalid-feedback d-block');
						$("#age").removeClass('is-invalid');
						$(".designationError").html("").removeClass('invalid-feedback d-block');
						$("#designation").removeClass('is-invalid');
						$(".dobError").html("").removeClass('invalid-feedback d-block');
						$("#dob").removeClass('is-invalid');
						$(".genderError").html("").removeClass('invalid-feedback d-block');
						$("#gender").removeClass('is-invalid');
						$(".mobileError").html("").removeClass('invalid-feedback d-block');
						$("#mobile").removeClass('is-invalid');
						$(".skillError").html("").removeClass('invalid-feedback d-block');
						$("#skill").removeClass('is-invalid');
						$(".usernameError").html("").removeClass('invalid-feedback d-block');
						$("#username").removeClass('is-invalid');
						$(".password1Error").html("").removeClass('invalid-feedback d-block');
						$("#password1").removeClass('is-invalid');
						$(".password2Error").html("").removeClass('invalid-feedback d-block');
						$("#password2").removeClass('is-invalid');

						var id = response["row"]["id"];
						$("#row-"+id+" .modelName").html(response["row"]["name"]);
						$("#row-"+id+" .modelDob").html(response["row"]["dob"]);
						$("#row-"+id+" .modelAge").html(response["row"]["age"]);
						$("#row-"+id+" .modelMobile").html(response["row"]["mobile"]);
						$("#row-"+id+" .modelSkill").html(response["row"]["skill"]);
						$("#row-"+id+" .modelGender").html(response["row"]["gender"]);
						$("#row-"+id+" .modelDesignation").html(response["row"]["designation"]);
						$("#row-"+id+" .modelAddress").html(response["row"]["address"]);
						$("#row-"+id+" .modelUsername").html(response["row"]["username"]);
					}
				}
			});
		});


	function confirmDeleteModel(id){
		$("#deleteModel").modal("show");
		$("#deleteModel .modal-body").html("are you sure you want to delete this record?");
		$("#deleteModel").data("id",id);
	}

	function deleteNow(){
		var id = $("#deleteModel").data('id');

		$.ajax({
				url: '<?php echo base_url().'index.php/EmployeeModel/deleteModel/'; ?>'+id,
				type: 'POST',
				data: $(this).serializeArray(),				
				dataType: 'json',
				success: function(response){
					if (response['status'] == 1) {
						$("#deleteModel").modal("hide");
						$("#ajax_Response .modal-body").html(response['msg']);
						$("#ajax_Response").modal("show");
					}else{
						$("#deleteModel").modal("hide");
						$("#ajax_Response .modal-body").html(response['msg']);
						$("#ajax_Response").modal("show");	
					}
				}
			});
	}


	var check = function() {
		  if (document.getElementById('password1').value ==
		    document.getElementById('password2').value) {
		    document.getElementById('msg').style.color = 'green';
		    document.getElementById('msg').innerHTML = 'password is ok';
		  } else {
		    document.getElementById('msg').style.color = 'red';
		    document.getElementById('msg').innerHTML = 'password not matching';
		  }
		}
	</script>
	<script>
		$('table.table-sortable th').on('click', function(e) {
  sortTableByColumn(this)
})

function sortTableByColumn(tableHeader) {
	  // extract all the relevant details
	  let table = tableHeader.closest('table')
	  let index = tableHeader.cellIndex
	  let sortType = tableHeader.dataset.sortType
	  let sortDirection = tableHeader.dataset.sortDir || 'asc' // default sort to ascending

	  // sort the table rows
	  let items = Array.prototype.slice.call(table.rows);
	  let sortFunction = getSortFunction(sortType, index, sortDirection)
	  let sorted = items.sort(sortFunction)

	  // remove and re-add rows to table
	  for (let row of sorted) {
	    let parent = row.parentNode
	    let detatchedItem = parent.removeChild(row)
	    parent.appendChild(row)
	  }

	  // reset heading values and styles
	  for (let header of tableHeader.parentNode.children) {
	    header.classList.remove('currently-sorted')
	    delete header.dataset.sortDir
	  }

	  // update this headers's values and styles
	  tableHeader.dataset.sortDir = sortDirection == 'asc' ? 'desc' : 'asc'
	  tableHeader.classList.add('currently-sorted')
	}

	function getSortFunction(sortType, index, sortDirection) {
	  let dir = sortDirection == 'asc' ? -1 : 1
	  switch (sortType) {
	    case 'text': return stringRowComparer(index, dir);
	    case 'numeric': return numericRowComparer(index, dir);
	    default: return stringRowComparer(index, dir);
	  }
	}

	// asc = alphanumeric order - eg 0->9->a->z
	// desc = reverse alphanumeric order - eg z->a->9->0
	function stringRowComparer(index, direction) {
	  return (a, b) => -1 * direction * a.children[index].textContent.localeCompare(b.children[index].textContent)
	}

	// asc = higest to lowest - eg 999->0
	// desc = lowest to highest - eg 0->999
	function numericRowComparer(index, direction) {
	  return (a, b) => direction * (Number(a.children[index].textContent) - Number(b.children[index].textContent))
	}

</script>
</body>
</html>