<form method="POST" action="" name="editEmployeeModel" id="editEmployeeModel" enctype="multipart/form-data">
	<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
	<div class="modal-body">
		<div class="form-group">
			<label>Name</label>	
			<input type="text" name="name" id="name" value="<?php echo $row['name']; ?>" placeholder="Enter Name" class="form-control">
			<p class="nameError"></p>	
		</div>
		<div class="form-group">
			<label>DOB</label>	
			<input type="date" name="dob" id="dob" value="<?php echo $row['dob']; ?>" class="form-control">
			<p class="dobError"></p>	
		</div>
		<div class="form-group">
			<label>Age</label>	
			<input type="number" name="age" id="age" value="<?php echo $row['age']; ?>" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==3) return false;" placeholder="Enter Age" class="form-control">	
			<p class="ageError"></p>
		</div>
		<div class="form-group">
			<label>Mobile</label>	
			<input type="number" name="mobile" id="mobile" value="<?php echo $row['mobile']; ?>" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;" placeholder="Enter Mobile" class="form-control">	
			<p class="mobileError"></p>
		</div>
		<div class="form-group">
			<label>Skill</label>	
			<input type="text" name="skill" id="skill" value="<?php echo $row['skill']; ?>" placeholder="Enter Skill" class="form-control">	
			<p class="skillError"></p>
		</div>
		<div class="form-group">
			<label>Gender</label>	
			<select name="gender" id="gender" value="" class="form-control">
				<option value="<?php echo $row['gender']; ?>" selected><?php echo $row['name']; ?></option>
				<option value="Male" <?php echo ($row['gender']=="Male") ? 'selected' : '' ; ?>>Male</option>
				<option value="Female" <?php echo ($row['gender']=="Female") ? 'selected' : '' ; ?>>Female</option>
			</select>
			<p class="genderError"></p>
		</div>
		<div class="form-group">
			<label>Designation</label>	
			<input type="text" name="designation" id="designation" value="<?php echo $row['designation']; ?>" placeholder="Enter Designation" class="form-control">
			<p class="designationError"></p>	
		</div>
		<div class="form-group">
			<label>Address</label>	
			<textarea name="address" id="address" placeholder="Enter Address" class="form-control"><?php echo $row['address']; ?></textarea>
			<p class="addressError"></p>	
		</div>
		
		<div class="form-group">
			<label>Username</label>	
			<input type="text" name="username" id="username" value="<?php echo $row['username']; ?>" placeholder="UserName" class="form-control">	
			<p class="usernamerror"></p>
		</div>
		<div class="form-group">
			<label>Password</label>	
			<input type="password" name="password1" id="password1" value="<?php echo $row['password']; ?>" placeholder="Password" class="form-control" onkeyup='check();'>
			<p class="password1Error"></p>	
		</div>
		<div class="form-group">
			<label>Confirm Password</label>	
			<input type="password" name="password2" id="password2" value="<?php echo $row['confirm_password']; ?>" placeholder="confirm password" class="form-control" onkeyup='check();'>
			<span id='msg'></span>
			<p class="password2Error"></p>	
		</div>	     
	</div>
	<div class="modal-footer">
		<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		<button type="submit" class="btn btn-primary">Submit</button>
	</div>
</form>
